import pyodbc
import os
import time
import pygatt
import requests
import sys
from datetime import datetime
from threading import Thread

#---DEFINITIONS------------------------------------------------------------
#defining connection datas
DB_DRIVER = 	"{ODBC Driver 17 for SQL Server}"
DB_SERVER = 	"tcp:blenetwork.database.windows.net,1433"
DB_DB = 	"SensorDatas"
DB_USERNAME = 	"blenetwork"
DB_PASSWORD = 	"A1s2d3a1s2D3"
API_POINT =	"http://blenetworks.azurewebsites.net/Home/"

#defining MSSQL cols
CONTROLLER_MAC_COL_MSSQL = 	3
CONTROLLER_STATE_COL_MSSQL = 	4
SENSOR_MAC_COL_MSSQL =		5
CONNECTION_COL_MSSQL = 		7
RULE_SENSOR_MAC_COL_MSSQL =	1
RULE_CONTROLLER_MAC_COL_MSSQL=	2
RULE_TYPE_COL_MSSQL=		3
RULE_VALUE_COL_MSSQL=		4
RULE_NEW_STATE_COL_MSSQL=	5
RULE_ISENABLED_COL_MSSQL=	6


#defining BLE UUIDs SHARED
DEVICE_NAME_UUID = 	"00002A00-0000-1000-8000-00805f9b34fb"

#defining BLE UUIDs for SENSORs
MEASUREMENT_UNIT_UUID = "00000001-a36d-4db4-8cb9-c88735f34cf2"
VALUE_UUID = 			"00000002-a36d-4db4-8cb9-c88735f34cf2"
IMAGES_UUID =			"00000003-a36d-4db4-8cb9-c88735f34cf2"

#defining BLE UUIDs for CONTROLLERs
SERIAL_UUID = "0000FFE1-0000-1000-8000-00805F9B34FB"

#defining LOG LEVEL
#--0:OFF-----------#
#--1:CONSOLE-------#
#--2:FILE----------#
#--3:CONSOLE+FILE--#
LOG_LEVEL = 1

#RFID card check interval in seconds
RFID_CHECK_INTERVAL = 1

#Scheduler check if has new task interval in seconds
SCHEDULER_TASK_CHECK_INTERVAL = 1

#BLE sensor update interval in seconds
SENSOR_UPDATE_INTERVAL = 600

#Controller state polling interval in seconds
CONTROLLER_UPDATE_INTERVAL = 0.5

#BLE connection TIMEOUT in seconds
CONN_TIMEOUT = 5

#gateway type
GATEWAY_TYPE = "Raspberry Pi3"

#defining SCHEDULER task priority levels
UPDATE_CONTROLLER_STATE_TASK = 1
ADD_CONTROLLER_TASK = 2
ADD_SENSOR_TASK = 2
UPDATE_SENSOR_TASK = 3

#---------------------------------------------------------------------------

#---THREAD HANDLING---------------------------------------------------------
#controller thread
class controllerUpdaterThread(Thread):
	def run(self):
		log("CONTROLLER UPDATER THREAD SPAWNED")
		cursor = dbconn()
		updateControllerCache(cursor)
		watchControllers(cursor)

#RFID reader thread
class RFIDReaderThread(Thread):
	def run(self):
		log("RFID READER THREAD SPAWNED")
		while True:
			readFromRFID()
			time.sleep(RFID_CHECK_INTERVAL)

#sensor updater caller thread
class sensorUpdaterThread(Thread):
	def run(self):
		log("SENSOR UPDATER THREAD SPAWNED")
		while True:
			cursor = dbconn()
			updateSensorCache(cursor)
			myrules.fillUpRuleTable(cursor)
			myrules.logRules()
			for sensor in sensorCache:
				log("Sensor update (" + str(sensor) + ") added to scheduler with priority level " + str(UPDATE_SENSOR_TASK))
				scheduler.addTask(schedulerTask(sensor, UPDATE_SENSOR_TASK))
			time.sleep(SENSOR_UPDATE_INTERVAL)

#scheduler thread
class schedulerThread(Thread):
	def run(self):
		log("SCHEDULER THREAD SPAWNED")
		while True:
			if(scheduler.hasNextTask()):
				while scheduler.hasNextTask():
					taskToDo = scheduler.getNextTask()
					if taskToDo.taskType == UPDATE_CONTROLLER_STATE_TASK:
						log("Executing CONTROLLER_UPDATE task on " + str(taskToDo.mac_address) + " to state -> " + str(taskToDo.newState))
						updateController(taskToDo.mac_address, taskToDo.newState)
					if taskToDo.taskType == ADD_CONTROLLER_TASK:
						log("Executing ADD_CONTROLLER task on " + str(taskToDo.mac_address))
						addController(taskToDo.mac_address)
					if taskToDo.taskType == ADD_SENSOR_TASK:
						log("Executing ADD_SENSOR task on " + str(taskToDo.mac_address))
						addSensor(taskToDo.mac_address)
					if taskToDo.taskType == UPDATE_SENSOR_TASK:
						log("Executing SENSOR_UPDATE task on " + str(taskToDo.mac_address))
						updateValue(taskToDo.mac_address)
			else:
				time.sleep(SCHEDULER_TASK_CHECK_INTERVAL)

#-----------------------------------------------------------------------------

#---SCHEDULER-----------------------------------------------------------------
class adapterScheduler:
	def __init__(self):
		self.tasks = []

	def addTask(self, task):
		self.tasks.append(task)

	def getNextTask(self):
		self.tasks.sort()
		if len(self.tasks) != 0:
			return self.tasks.pop(0)
	def hasNextTask(self):
		if len(self.tasks) != 0:
			return True
		else:
			return False

class schedulerTask:
	def __init__(self, mac_address, taskType, newState = 0):
		self.mac_address = mac_address
		self.taskType = taskType
		self.newState = newState

	def __lt__(self, other):
		return self.taskType < other.taskType

#------------------------------------------------------------------------------

#---RULES----------------------------------------------------------------------
class Rule:
	def __init__(self, sensor, rule_type, value, controller, new_state):
		self.sensor = sensor
		self.rule_type = rule_type
		self.value = value
		self.controller = controller
		self.new_state = new_state
	def getSensorMac(self):
		return self.sensor
	def getRuleType(self):
		return self.rule_type
	def getValue(self):
		return self.value
	def getControllerMac(self):
		return self.controller
	def getNewState(self):
		return self.new_state

class Rules:
	def __init__(self):
		self.rules = []
	def fillUpRuleTable(self, cursor):
		cursor.execute('SELECT * FROM [Rule]')
		for row in cursor:
			if row[RULE_ISENABLED_COL_MSSQL] is True:
				self.rules.append(Rule( row[RULE_SENSOR_MAC_COL_MSSQL],
							row[RULE_TYPE_COL_MSSQL],
							row[RULE_VALUE_COL_MSSQL],
							row[RULE_CONTROLLER_MAC_COL_MSSQL],
							row[RULE_NEW_STATE_COL_MSSQL]))
	def addRule(self, rule):
		self.rules.append(rule)
	def sensorValueRead(self, sensor, value):
		for rule in self.rules:
			if rule.getSensorMac() == sensor:
				if rule.getRuleType() == "Greater":
					if value > rule.getValue():
						if controllerCache[rule.getControllerMac()] != rule.getNewState():
							scheduler.addTask(schedulerTask(rule.getControllerMac(), UPDATE_CONTROLLER_STATE_TASK, rule.getNewState()))
							setControllerState(rule.getControllerMac());
							controllerCache[rule.getControllerMac()] = rule.getNewState()
				if rule.getRuleType() == "Less":
					if str(value) < str(rule.getValue()):
						if controllerCache[rule.getControllerMac()] != rule.getNewState():
							scheduler.addTask(schedulerTask(rule.getControllerMac(), UPDATE_CONTROLLER_STATE_TASK, rule.getNewState()))
							setControllerState(rule.getControllerMac());
							controllerCache[rule.getControllerMac()] = rule.getNewState()
				if rule.getRuleType() == "Equals":
					if value == str(rule.getValue()):
						if controllerCache[rule.getControllerMac()] != rule.getNewState():
							scheduler.addTask(schedulerTask(rule.getControllerMac(), UPDATE_CONTROLLER_STATE_TASK, rule.getNewState()))
							setControllerState(rule.getControllerMac());
							controllerCache[rule.getControllerMac()] = rule.getNewState()
	def logRules(self):
		for x in self.rules:
			log("ENABLED RULE: IF " + str(x.getSensorMac()) + " sensor value " +str(x.getRuleType()) + " THAN " +str(x.getValue()) +" SET " + str(x.getControllerMac()) +" TO "  +str(x.getNewState()))


#------------------------------------------------------------------------------

#logging function
def log(text):
	if(LOG_LEVEL == 0):
		return
	if(LOG_LEVEL == 1 or LOG_LEVEL == 3):
		print(datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " LOG: " + str(text))
	if(LOG_LEVEL == 2 or LOG_LEVEL == 3):
		file = open("logfile","a")
		file.write(datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " LOG: " + str(text) + "\n")
		file.close()


#setting CONTROLLER STATE
def updateController(mac, state):
	newValue = bytearray([1])
	if not state:
		newValue = bytearray([0])
	try:
		log("Starting adapter")
		adapter.start()
		log("Connecting to " + str(mac))
		device = adapter.connect(mac)
		log("Writing device(" + str(mac) + ") SERIAL (UUID -> " + SERIAL_UUID + ") to " + str(state))
		device.char_write(SERIAL_UUID, newValue)
		return True
	except Exception as exc:
		log("Error occured: " + str(type(exc)))
		return False
	finally:
		log("Stopping adapter")
		adapter.stop()

#adding new SENSOR to database returning TRUE if successful, FALSE if error occured
def addSensor(mac_address):
	try:
		#starting adapter
		log("Starting adapter")
		adapter.start()

		#connection to BLE device
		log("Connecting to " + str(mac_address))
		device = adapter.connect(mac_address, CONN_TIMEOUT)

		#reading DEVICE_NAME characteristic
		log("Reading DEVICE_NAME (UUID -> " + DEVICE_NAME_UUID + ") from device " + str(mac_address))
		name = device.char_read(DEVICE_NAME_UUID)
		log("DEVICE_NAME -> " + str(name))

		#reading MEASUREMENT_UNIT characteristic
		log("Reading MEASUREMENT_UNIT (UUID -> " + MEASUREMENT_UNIT_UUID + ") from device " + str(mac_address))
		measurement_unit_scanned = device.char_read(MEASUREMENT_UNIT_UUID).split(";")
		measurement_unit = measurement_unit_scanned[0]
		measurement_unit_display = measurement_unit_scanned[1]
		log("MEASUREMENT_UNIT -> " + str(measurement_unit))
		log("MEASUREMENT_UNIT_DISPLAY -> " + str(measurement_unit_display))

		#reading VALUE characteristic
		log("Reading VALUE (UUID -> " + VALUE_UUID + ") from device " + str(mac_address))
		value = device.char_read(VALUE_UUID)
		log("VALUE -> " + str(value))

		#reading IMAGES characteristic
		log("Reading IMAGES (UUID -> " + IMAGES_UUID + ") from device " + str(mac_address))
		images = device.char_read(IMAGES_UUID)
		log("IMAGES -> " + str(images))

		#adding SENSOR to gateway
		log("Adding " + str(name) + " (" + str(mac_address) + ") to gateway " + GATEWAY_TYPE)
		api_point = API_POINT + "AddSensor"
		data = {'Name' : "".join(map(chr, name)),
			'Unit' : "".join(map(chr, measurement_unit)),
			'MacAddress' : mac_address,
			'GatewayName' : GATEWAY_TYPE,
			'UnitDisplay' : "".join(map(chr, measurement_unit_display)),
			'Images' : "".join(map(chr, images)) }
		r = requests.post(url = api_point, data = data)
		log(r.text)

		#adding first VALUE of SENSOR if successfully added to gateway
		if not r.text.startswith('"Error'):
			log("Adding first value to " + str(name) + " (" + str(mac_address) + ")")
            		temp = "".join(map(chr,value))
	    		intTemp = temp.split(".")
			api = API_POINT + "AddSensorValue"
			data = {'Value' : intTemp[0],
				'MacAddress' : mac_address }
            		r = requests.post(url = api, data = data)
            		log(r.text)
			return True

	except Exception as exc:
		log("Error occured: " + str(type(exc)))
		return False
	finally:
		log("Stopping adapter")
		adapter.stop()

#SENSORVALUE update returning TRUE if successful, FALSE if error occured
def updateValue(mac_address):
	try:
		#starting adapter
		log("Starting adapter")
		adapter.start()

		#connection to BLE device
		log("Connecting to " + str(mac_address))
		device = adapter.connect(mac_address, CONN_TIMEOUT)

		#reading VALUE characteristic
		log("Reading VALUE (UUID -> " + VALUE_UUID + ") from device " + str(mac_address))
		value = device.char_read(VALUE_UUID)
		log("VALUE -> " + str(value))

		#adding new VALUE to sensor
		log("Adding value to " + str(mac_address))
		temp = "".join(map(chr,value))
    		intTemp = temp.split(".")
		api = API_POINT + "AddSensorValue"
		data = {'Value' : intTemp[0],
			'MacAddress' : mac_address }
            	r = requests.post(url = api, data = data)
            	log(r.text)
		myrules.sensorValueRead(mac_address,intTemp[0])

		if connectionCache[str(mac_address)] is not True:
			log("Setting sensor "+ str(mac_address) + ") CONNECTION_STATE to TRUE")
			setConnectionState(str(mac_address), True)
		return True

	except Exception as exc:
		if connectionCache[str(mac_address)] is not False:
			log("Setting sensor "+ str(mac_address) + ") CONNECTION_STATE to FALSE")
			setConnectionState(str(mac_address), False)
		log("Error occured: " + str(type(exc)))
		return False
	finally:
		log("Stopping adapter")
		adapter.stop()

#adding new controller to database
def addController(mac_address):
	try:
		#starting adapter
		log("Starting adapter")
		adapter.start()

		#connection to BLE device
		log("Connecting to " + str(mac_address))
		device = adapter.connect(mac_address, CONN_TIMEOUT)

		#reading DEVICE_NAME characteristic
		log("Reading DEVICE_NAME (UUID -> " + DEVICE_NAME_UUID + ") from device " + str(mac_address))
		name = device.char_read(DEVICE_NAME_UUID)
		log("DEVICE_NAME -> " + str(name))

		#adding SENSOR to gateway
		log("Adding " + str(name) + " (" + str(mac_address) + ") to gateway " + GATEWAY_TYPE)
		api_point = API_POINT + "AddController"
		data = {'Name' : "".join(map(chr, name)),
			'MacAddress' : mac_address,
			'GatewayName' : GATEWAY_TYPE }
		r = requests.post(url = api_point, data = data)
		log(r.text)
		return True

	except Exception as exc:
		log("Error occured: " + str(type(exc)))
		return False
	finally:
		log("Stopping adapter")
		adapter.stop()

#TODO reading RFID data
def readFromRFID():
	print("TODO")

#connect to database
def dbconn():
	#setting up connection
	conn = pyodbc.connect('DRIVER='+DB_DRIVER+';PORT=1433;SERVER='+ DB_SERVER +';PORT=1443;DATABASE=' + DB_DB + ';UID=' + DB_USERNAME + ';PWD=' + DB_PASSWORD)
	cursor = conn.cursor()
	return cursor;

#watching CONTROLLER STATEs, adding task to scheduler if changed
def watchControllers(cursor):
	while True:
		time.sleep(CONTROLLER_UPDATE_INTERVAL)
		cursor.execute('SELECT * FROM MyControllers')

		for row in cursor:
			if row[CONTROLLER_MAC_COL_MSSQL] not in controllerCache.keys():
				controllerCache[row[CONTROLLER_MAC_COL_MSSQL]] = row[CONTROLLER_STATE_COL_MSSQL]
			if controllerCache[row[CONTROLLER_MAC_COL_MSSQL]] != row[CONTROLLER_STATE_COL_MSSQL]:
				controllerCache[row[CONTROLLER_MAC_COL_MSSQL]] = row[CONTROLLER_STATE_COL_MSSQL]
				scheduler.addTask(schedulerTask(row[CONTROLLER_MAC_COL_MSSQL], UPDATE_CONTROLLER_STATE_TASK, row[CONTROLLER_STATE_COL_MSSQL]))
				log("Controller update (" + str(row[CONTROLLER_MAC_COL_MSSQL]) + ") added to scheduler with priority level " + str(UPDATE_CONTROLLER_STATE_TASK))

#initializing CONTROLLER CACHE
def updateControllerCache(cursor):
	cursor.execute('SELECT * FROM MyControllers')
	for row in cursor:
		controllerCache[row[CONTROLLER_MAC_COL_MSSQL]] = row[CONTROLLER_STATE_COL_MSSQL]

#initalizing SENSOR CACHE
def updateSensorCache(cursor):
	del sensorCache[:]
	cursor.execute('SELECT * FROM Sensor')
	for row in cursor:
		sensorCache.append(row[SENSOR_MAC_COL_MSSQL])
		connectionCache[row[SENSOR_MAC_COL_MSSQL]] = row[CONNECTION_COL_MSSQL]

#sets connection state on website FALSE is not connected TRUE if connected
def setConnectionState(mac_address, state):
		api_point = API_POINT + "SetSensorConnectionState"
		data = {'MacAddress' : mac_address,
			'connected' : state }
		r = requests.post(url = api_point, data = data)
		log(r.text)

#sets controller state on website was FALSE -> TRUE, was TRUE -> FALSE
def setControllerState(mac_address):
		api_point = API_POINT + "SetControllerState"
		data = {'MacAddress' : mac_address }
		r = requests.post(url = api_point, data = data)
		log(r.text)

def test(testCode):
		if testCode == "test1":
			schedulerThread().start()
			sensorUpdaterThread().start()

		if testCode == "test2":
			addSensor("30:AE:A4:19:A8:AE")

		if testCode == "test3":
			schedulerThread().start()
			controllerUpdaterThread().start()
		if testCode == "test4":
			schedulerThread().start()
			controllerUpdaterThread().start()
			addController("00:25:83:00:62:A3")

		if testCode == "test5":
			schedulerThread().start()
			controllerUpdaterThread().start()
			sensorUpdaterThread().start()


#MAIN PROGRAM----------------------------------------------

#initializing BT adapter
adapter = pygatt.GATTToolBackend()

#cache for controllers
controllerCache = {}

#cache for connection states
connectionCache = {}

#cache for sensors
sensorCache = []

#initializing task scheduler
scheduler = adapterScheduler()

#initializing rule table
myrules = Rules()

#MAIN PROGRAM TO RUN EVERYTHING
#spawning threads
#schedulerThread().start()
#controllerUpdaterThread().start()
#sensorUpdaterThread().start()
#RFIDReaderThread().start()

#RUN TEST CASES
test(sys.argv[1])

#------------------------------------------------------------
#TODO WEBSITE
#TODO amchart csak akkor rajzoljon hogyha van adat

#TODO PROGRAM
#TODO ha nem sikerul a sensor-/controller-update akkor kapcsolodjon ujra
#TODO RFID implementalas
#TODO RPIRE PORTOLNI AZ EGESZET

#TODO DOKSI
#TODO szalak abrazolasara es mukodesere valami fancy abra
#TODO GATT profilok abrazolasa
#TODO utemezorol abra
